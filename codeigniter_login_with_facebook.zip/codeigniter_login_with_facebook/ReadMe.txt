Author : CodexWorld
Author URI : http://www.codexworld.com/
Author Email: contact@codexworld.com
Tutorial Link: http://www.codexworld.com/facebook-login-codeigniter/

Installation Instructtion:
==================================================
1. Import the users.sql file into the database of your CodeIgniter application.
2. Move all files to the same directory of your CodeIgniter application.
3. Open the "application/config/facebook.php" file and specify App ID (facebook_app_id) and App Secret (facebook_app_secret) according to your Facebook App credentials.
4. Open the URL (http://localhost/project_folder_name/user_authentication) on the browser and test the login with Facebook in CodeIgniter.

============ May I Help You ===========
If you have any query about this script, please feel free to comment here - http://www.codexworld.com/facebook-login-codeigniter/#respond. We will reply your query ASAP.